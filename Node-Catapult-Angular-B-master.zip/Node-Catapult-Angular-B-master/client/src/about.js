'use strict';

  module.exports = function($scope,$http) {
    $scope.header = 'I am ready to be built!';	
  };
