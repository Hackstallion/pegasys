'use strict';


  module.exports = function($scope) {
  	$scope.welcome = 'Welcome to your App!';
  	$scope.buttonText = 'This is your Button';
  };
